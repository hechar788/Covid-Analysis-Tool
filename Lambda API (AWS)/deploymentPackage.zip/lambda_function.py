import json
from controller import covidStats

def lambda_function(event, context):
    targetCountries = event.get('targetCountries', [])
    targetDates = event.get('targetDates', [])
    
    result = covidStats(targetCountries, targetDates)
    
    return {
        'statusCode': 200,
        'body': json.dumps(result)
    }